var dbDao = require('../helpers/dbDao');

function getDetails(req,res) {
	return {FlightResponse:dbDao.queryCollection("flight_details")};
}

module.exports = {
	getDetails
};