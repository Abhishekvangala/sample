var db = global.db;
function queryCollection(collectionName,options){
	return options ? db.collection(collectionName).find(options): db.collection(collectionName).find();
}

function updateCollection(filter,newValues,collectionName){
	db.collection(collectionName).updateMany(myquery, newvalues, function(err, res) {
    if (err) throw err;
    console.log(res.result.nModified + " document(s) updated");
  });
}

module.exports = {queryCollection,updateCollection};