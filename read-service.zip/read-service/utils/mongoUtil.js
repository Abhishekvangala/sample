var mongoclient = require('mongodb').MongoClient;

var _db;

var connectDb= function(config,callback) {
	console.log("getting called while loading strange"); 
	if(_db) {
		console.log("connection already existing skipping");
	}
	else{
	mongoclient.connect("mongodb://localhost:27017/FlightDB",function(err,db){
		if(!err){
			console.log('Connected ');
			_db = db;
			console.log(_db);
		}else{
			return callback(err);
	}
	});
}}
	
var getDb = function(){
	console.log('function called');
	console.log(_db);
	return _db;
	}

module.exports = {connectDb,getDb};
