'use strict';

var SwaggerExpress = require('swagger-express-mw');
var mongoUtils = require('./utils/mongoUtil');
var app = require('express')();
module.exports = app; // for testing

var config = {
  appRoot: __dirname // required config
};

var dummyConfig = {};

var dummyFunction = function(err){
	if(err) console.log(err);
}

SwaggerExpress.create(config, function(err, swaggerExpress) {
  if (err) { throw err; }

  // install middleware
  swaggerExpress.register(app);

  var port = process.env.PORT || 10010;
  app.listen(port);

  if (swaggerExpress.runner.swagger.paths['/hello']) {
    console.log('try this:\ncurl http://127.0.0.1:' + port + '/hello?name=Scott');
  }
});

mongoUtils.connectDb(dummyConfig,dummyFunction);
global.db = mongoUtils.getDb();
console.log(global.db);

